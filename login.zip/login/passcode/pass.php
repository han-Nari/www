<?php 

$error = array("passCode" => "");
if($_SERVER['REQUEST_METHOD'] == 'POST') {
		try {
			function dataInput($data) {
	    	   $data = trim($data);
	      	   $data = stripslashes($data);
	      	   $data = htmlspecialchars($data);
	           return $data;
            }

            $passCode = dataInput($_POST["password"]);

            $query = $pdo->prepare("SELECT * FROM code WHERE passcode = :passcode");
	        $query->bindParam(":passcode", $passCode, PDO::PARAM_STR);
	        $query->execute();
	        $result = $query->fetch(PDO::FETCH_ASSOC);

	        if(!$result) {
	             $error["passCode"] = "passcode not found";
	          } else {
	          	 $_SESSION["passCode"] = $passCode;
	             header("location:../admins/admins.php");
	        }
		} catch(PDOException $e) {
	      die("Connection failed" . $e->getMessage());
	   }
}